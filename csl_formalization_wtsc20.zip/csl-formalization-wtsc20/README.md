# Mechanization of CSL

This folder includes the mechanization of CSL as described in the paper
"A Formally Verified Static Analysis Framework for Compositional Contracts" 

The proofs are checked with Coq 8.10.1 (currently with warnings) on Linux and require no external dependencies.

To check all the proofs navigate to CSL and run the makefile:
```
$ cd CSL
$ make
```

## File structure
- [Definitions.v](Definitions.v) contains miscelanous definitions used throughout the development
- [Exp.v](Exp.v) defines the denotation of expressions and its properties
- [HList.v](HList.v) contains a standard implementation of heterogenous lists together with their properties
- [Satisfaction.v](Satisfaction.v) defines the satisfaction relation as presented in Section 3
- [Syntax.v](Syntax.v) defines the syntax of contracts and expressions, as well as substitution and its properties.
- [Tactics.v](Tactics.v) contains simple, non-specific tactics
- [Analysis/AbstractValues.v](Analysis/AbstractValues.v) defines abstract sets and values, operations on them and their properties
- [Analysis/DefParticip.v](Analysis/DefParticip.v)  and [Analysis/DefParticipGeneric.v](Analysis/DefParticipGeneric.v) contain the definite participation analysis as an instance of the `CSLAnalysis`
- [Analysis/Fairness.v](Analysis/Fairness.v) and [Analysis/FairnessGeneric.v](Analysis/FairnessGeneric.v) contain the fairness analysis as an instance of the `CSLAnalysis`
- [Analysis/Generic.v](Analysis/Generic.v) contains the class definitions for both expression analysis (`PredicateAnalysis`) and contract analysis (`CSLAnalysis`), as well as their properties (incl. soundness)
- [Analysis/IdPredicateAnalysis.v](Analysis/IdPredicateAnalysis.v) contains the simple identity analysis as an instance of `PredicateAnalysis`
- [Analysis/Interval.v](Analysis/Interval.v) defines integer intervals and their properties, used in fairness analysis
- [Analysis/Lattice.v](Analysis/Lattice.v) contains the general lattice type class and the functional lattice instance, the latter used in fairness analysis
- [Analysis/Participation.v](Analysis/Participation.v) and [Analysis/ParticipationGeneric.v](Analysis/ParticipationGeneric.v) contain the potential participation analysis as an instance of the `CSLAnalysis`
- [Analysis/SingletonSet.v](Analysis/SingletonSet.v) defines the notion of singleton sets, which is used in both fairness and definite participation analysis

## Theorems from the paper

- Theorem 1, soundness of approximation, ` csl_analysis_sound` in [Analysis/Generic.v](Analysis/Generic.v)
- Theorem 2, soundness of widening, `env_widening_sound` in [Analysis/Generic.v](Analysis/Generic.v)
- Lemma 1, in potential participation analysis β is a homomorphism w.r.t. append and interleaving, `β_append` and `β_interleave` in  [Analysis/ParticipationGeneric.v](Analysis/ParticipationGeneric.v)
- Lemma 2, in fairness analysis β is a homomorphism w.r.t. append and interleaving, proven directly in definition of `fairness_analysis` instance in [Analysis/FairnessGeneric.v](Analysis/FairnessGeneric.v)
