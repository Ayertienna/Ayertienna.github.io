# Mechanization of CSL

This folder includes the mechanization of CSL as described in the paper
"A Formally Verified Static Analysis Framework for Compositional Contracts" 

The proofs are checked with Coq 8.11 on Linux and require no external dependencies.

To check all the proofs navigate to CSL and run the makefile:
```
$ cd CSL
$ make
```

## File structure
- [Definitions.v](CSL/Definitions.v) contains miscelanous definitions used throughout the development
- [Denotational.v](CSL/Denotational.v) implements the denotational semantics using approximation levels
- [Exp.v](CSL/Exp.v) defines the denotation of expressions and its properties
- [HList.v](CSL/HList.v) contains a standard implementation of heterogenous lists together with their properties
- [Satisfaction.v](CSL/Satisfaction.v) defines the satisfaction relation as presented in Section 3
- [Syntax.v](CSL/Syntax.v) defines the syntax of contracts and expressions, as well as substitution and its properties.
- [Tactics.v](CSL/Tactics.v) contains simple, non-specific tactics
- [Analysis/AbstractValues.v](CSL/Analysis/AbstractValues.v) defines abstract sets and values, operations on them and their properties
- [Analysis/Algorithms.v](CSL/Analysis/Algorithms.v) gives an example instance of a non-trivial expression analysis, focusing on the equality restrictions; used in participation analysis
- [Analysis/DefParticip.v](CSL/Analysis/DefParticip.v)  and [Analysis/DefParticipGeneric.v](CSL/Analysis/DefParticipGeneric.v) contain the definite participation analysis as an instance of the `CSLAnalysis`
- [Analysis/Fairness.v](CSL/Analysis/Fairness.v) and [Analysis/FairnessGeneric.v](CSL/Analysis/FairnessGeneric.v) contain the fairness analysis as an instance of the `CSLAnalysis`
- [Analysis/Generic.v](CSL/Analysis/Generic.v) contains the class definitions for both expression analysis (`PredicateAnalysis`) and contract analysis (`CSLAnalysis`), as well as their properties (incl. soundness)
- [Analysis/IdPredicateAnalysis.v](CSL/Analysis/IdPredicateAnalysis.v) contains the simple identity analysis as an instance of `PredicateAnalysis`
- [Analysis/Interval.v](CSL/Analysis/Interval.v) defines integer intervals and their properties, used in fairness analysis
- [Analysis/Lattice.v](CSL/Analysis/Lattice.v) contains the general lattice type class and the functional lattice instance, the latter used in fairness analysis
- [Analysis/Participation.v](CSL/Analysis/Participation.v) and [Analysis/ParticipationGeneric.v](CSL/Analysis/ParticipationGeneric.v) contain the potential participation analysis as an instance of the `CSLAnalysis`
- [Analysis/SingletonSet.v](CSL/Analysis/SingletonSet.v) defines the notion of singleton sets, which is used in both fairness and definite participation analysis

## Theorems from the paper

- Theorem 1, soundness of approximation, ` csl_analysis_sound` in [Analysis/Generic.v](CSL/Analysis/Generic.v)
- Theorem 2, soundness of widening, `env_widening_sound` in [Analysis/Generic.v](CSL/Analysis/Generic.v)
- Lemma 1, in potential participation analysis β is a homomorphism w.r.t. append and interleaving, `β_append_Incl_{R,L}` and `β_interleave_Incl_{R,L}` in  [Analysis/ParticipationGeneric.v](CSL/Analysis/ParticipationGeneric.v)
- Lemma 2, in fairness analysis β is a homomorphism w.r.t. append and interleaving, `β_append_eq` and `β_interleave_eq` in [Analysis/FairnessGeneric.v](CSL/Analysis/FairnessGeneric.v)
- Lemma 3, in definite participation analysis  β is a homomorphism w.r.t. append and interleaving, `β_append_Incl_{R,L}` and `β_interleave_Incl_{R,L}` in  [Analysis/DefParticipGeneric.v](CSL/Analysis/DefParticipGeneric.v)
